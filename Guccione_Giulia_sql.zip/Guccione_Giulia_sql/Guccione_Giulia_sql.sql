Create Database Vendite_regione;

CREATE TABLE Product (
    ID_prodotto INT auto_increment PRIMARY KEY unique,
    Nome_prodotto VARCHAR(100),
    Categoria VARCHAR(100),
    prezzo_unità Decimal(10,2)
);

CREATE TABLE Region (
    ID_regione INT auto_increment PRIMARY KEY unique,
    Nome_regione VARCHAR(100)
);
CREATE TABLE Sales (
    ID_vendita INT auto_increment PRIMARY KEY unique,
    Data DATE,
    Quantità INT,
    Importo DECIMAL(10, 2),
    ID_prodotto INT,
    ID_regione INT,
    FOREIGN KEY (ID_prodotto) REFERENCES Product(ID_prodotto),
    FOREIGN KEY (ID_regione) REFERENCES Region(ID_regione)
);




-- Popolamento delle tabelle--
INSERT INTO Product (Nome_prodotto, Categoria,prezzo_unità) VALUES
('Palla da basket', 'Sport', 5),
( 'PC Clementoni', 'Giochi educativi', 50),
('Peluches', 'Giochi per bambini',10),
( 'Macchinine', 'Giochi per bambini',5),
('giochi da tavolo','Giochi educativi', 10),
( 'palline da tennis', 'Sport', 3),
( 'skateboard', 'Sport', 35);

INSERT INTO Region (Nome_regione) VALUES
( 'Sicilia'),
( 'Lombardia'),
( 'Marche'),
('Emilia Romagna'),
( 'Toscana');

INSERT INTO Sales ( Data, Quantità, Importo, ID_prodotto, ID_regione) VALUES
('2022-03-16', 400, 2000.00, 1, 1),
( '2023-04-30', 25, 1250.00, 2, 2),
( '2020-07-07', 49, 490.00, 3, 1),
( '2019-09-06', 68, 340.00, 4, 3),
('2022-12-12', 20, 200.00, 5, 1);

---quesito uno---
SELECT 
    p.Nome_prodotto,
    YEAR(s.Data) AS Anno,
    SUM(s.Importo) AS Fatturato_totale
FROM
    Product as p
        INNER JOIN
    Sales as s ON p.ID_prodotto = s.ID_prodotto
GROUP BY p.Nome_prodotto , YEAR(s.Data)
ORDER BY YEAR(s.Data) , Fatturato_totale DESC;

---quesito due---

SELECT 
    r.Nome_regione, YEAR(s.Data) AS Anno, SUM(s.Importo) as Fatturato
FROM
    sales AS s
        INNER JOIN
    region AS r ON s.Id_regione = r.Id_regione
GROUP BY YEAR(s.Data) , r.Nome_regione
ORDER BY YEAR(S.Data) DESC , SUM(S.Importo) DESC;


---quesito tre(prima interpretazione)---

SELECT 
    p.Categoria, COUNT(p.Categoria) AS Numero_vendite
FROM
    Product AS p
        INNER JOIN
    Sales AS s ON p.ID_prodotto = s.ID_prodotto
GROUP BY p.Categoria
ORDER BY Numero_vendite DESC
LIMIT 1;

---quesito tre(seconda interpretazione)---

SELECT 
    p.Categoria, SUM(S.Quantità) AS Numero_vendite
FROM
    Product AS p
        INNER JOIN
    Sales AS s ON p.ID_prodotto = s.ID_prodotto
GROUP BY p.Categoria
ORDER BY Numero_vendite DESC
LIMIT 1;

---quesito quattro(primo metodo)---

SELECT p.*
FROM Product as p
LEFT JOIN Sales as s ON p.ID_prodotto = s.ID_prodotto
WHERE s.ID_vendita IS NULL;

---quesito quattro(secondo metodo)---

SELECT *
FROM Product
WHERE ID_prodotto NOT IN (SELECT ID_prodotto FROM Sales);


---quesito cinque---

SELECT 
    p.Nome_prodotto, MAX(s.Data) AS Ultima_data_vendita
FROM
    Product AS p
        LEFT JOIN
    Sales AS s ON p.ID_prodotto = s.ID_prodotto
GROUP BY p.ID_prodotto , p.Nome_prodotto
ORDER BY Ultima_data_vendita DESC;





